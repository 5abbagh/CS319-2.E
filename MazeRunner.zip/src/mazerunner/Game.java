
package mazerunner;

import java.awt.Dimension;
import java.awt.Point;

public class Game 
{
    public static void main(String[] args) 
    {
    	Console cn = new Console();
    	cn.setPreferredSize(new Dimension (1366,768));
    	cn.setLocation(new Point (250,100));
    }
}

